package App;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void init() throws Exception {
        Lang.getInstance().init(null);
        //handle ini and lang
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
        System.out.println("hi");

        System.out.println(Lang.getInstance().getString("Fox"));

        System.exit(0);
        Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }



    public static void main(String[] args) {
        launch(args);
    }
}
