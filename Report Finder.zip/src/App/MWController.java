package App;

public class MWController {
    public static MWController instance;

    public void initialize(){
        instance = this;
    }
}
