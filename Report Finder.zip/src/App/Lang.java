package App;

import java.io.File;
import java.util.HashMap;

public class Lang {
    private HashMap<String, String> words;

    private static Lang instance = null;
    private Lang(){
        words = new HashMap<String, String>();
    }

    public static Lang getInstance() {
        if(instance==null)
            instance = new Lang();
        return instance;
    }

    public void init(String path){
        File LangFile = null;
        if(path == null){
            //loading default language file
            LangFile = new File("Lang\\En_def.lan");


        }else{
            //Loading language file from path
        }

        //TODO

    }

    public String getString(String label){
        return words.get(label);
    }
}
